# Pinning Demo with ScrollMagic  
**Description**: Pinning Demo with Scroll Magic for youtube demo  
**Author**: Donal D'silva  
**Date**: 08/06/2019  
**Repo**: https://github.com/donyd/ScrollMagicDemo  
**YouTube**: https://youtu.be/RJ_lLOESI6o  